# MERN-Student-Management-System

Backend
